TakanaFy - Credits : [tj3e] (Discord) / InstGram : [takanax69]

A custom Spotify-inspired music player built with C# WPF (.NET 8).

Requirements :
- [.NET 8 SDK](https://dotnet.microsoft.com/download/dotnet/8)
- Windows 10/11

File Storage : 

All your music is stored locally:
-TakanaFy is only about 5MB which is better than Spotify (400MB)
  
   /Music/TakanaFy/
  ├── Music/          ← MP3 files (local + downloaded)
  ├── Covers/         ← Album art images
  └── Data/
      ├── songs.json      ← Song library metadata
      └── playlists.json  ← Playlist data

License :
MIT — free to use, modify, and distribute.
