╔══════════════════════════════════════════════════════════════════════╗
║                         TakanaFy v1.0                               ║
║              A Spotify-inspired Desktop Music Player                ║
╚══════════════════════════════════════════════════════════════════════╝

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
  REQUIREMENTS
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

  - Windows 10 or 11 (64-bit)
  - .NET 8 SDK or Runtime
      Download: https://dotnet.microsoft.com/download/dotnet/8.0
  - Internet connection (for YouTube search/download, lyrics, Last.fm)

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
  OPTIONAL SETUP (API KEYS)
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

  Open Settings (⚙ icon, bottom-left) to configure:

  ┌─ YouTube Search ────────────────────────────────────────────────┐
  │  Without a key: yt-dlp is used as a fallback (slower)           │
  │  With a key:    YouTube Data API v3 (fast, 10,000/day free)     │
  │                                                                  │
  │  Get your free key:                                              │
  │    1. Go to https://console.cloud.google.com                    │
  │    2. Create a project                                           │
  │    3. Enable "YouTube Data API v3"                               │
  │    4. Create an API Key                                          │
  │    5. Paste it into Settings → YouTube API Key                  │
  └──────────────────────────────────────────────────────────────────┘

  ┌─ Spotify Browse ────────────────────────────────────────────────┐
  │  For browsing the Spotify catalog (no playback, browse only):   │
  │    1. Go to https://developer.spotify.com/dashboard             │
  │    2. Create an app                                              │
  │    3. Copy Client ID + Client Secret                             │
  │    4. Paste both into Settings → Spotify                        │
  └──────────────────────────────────────────────────────────────────┘

  ┌─ Last.fm Scrobbling ────────────────────────────────────────────┐
  │  Track your listening history on Last.fm:                        │
  │    1. Go to https://www.last.fm/api/account/create              │
  │    2. Create an API account                                      │
  │    3. Copy API Key + API Secret                                  │
  │    4. Paste into Settings → Last.fm → click Connect             │
  │    5. Authorize in the browser that opens                        │
  └──────────────────────────────────────────────────────────────────┘

  ┌─ Discord Rich Presence ──────────────────────────────────────────┐
  │  Shows what you're playing on your Discord profile.              │
  │  Works automatically if Discord is running — no setup needed.    │
  └──────────────────────────────────────────────────────────────────┘

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
  FEATURES
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

  LIBRARY
  ───────
  • Upload local MP3/FLAC/WAV/M4A files with cover art auto-detection
  • Import an entire folder at once (📁 Import Folder)
  • Sort by Title, Artist, Duration, or Play Count (click column headers)
  • Export/Import your whole library as a JSON backup file
  • Bulk Select mode: tick multiple songs, then delete or add to playlist
  • Play count tracked per song, displayed in the library
  • Smart Playlists (✨ Smart button) auto-generates:
      - ✨ Most Played   (top 25 by play count)
      - 🆕 Recently Added (last 25 added)
      - ❤️  Favorites      (marked as favorite)
      - 🎲 Never Played  (play count = 0)

  SEARCH & YOUTUBE
  ────────────────
  • Search YouTube by name — auto-suggest from your local library as you type
  • Download audio from YouTube (saves to library permanently)
  • Stream YouTube audio without downloading (▶ Stream button)
  • Offline Mode (🟢/🔴 toggle in sidebar) — blocks all internet features

  PLAYLISTS
  ─────────
  • Create, rename, delete playlists
  • Set custom cover art per playlist
  • Add songs from library or search results
  • Drag-and-drop reordering (planned)

  PLAYBACK
  ────────
  • Shuffle and repeat modes
  • 10-band equalizer with 7 presets (Flat, Bass Boost, Treble Boost,
    Vocal Boost, Electronic, Rock, Classical)
  • Audio device selection (in Settings → Playback)
  • Up Next queue — see and manage what plays next
  • Keyboard media keys supported (⏯ ⏭ ⏮ on your keyboard)
  • System tray support — minimize to tray, control from tray icon

  LYRICS
  ──────
  • Synced lyrics fetched automatically from LRCLIB (free, no key needed)
  • Dynamic glowing lyrics: the active line glows in your theme color
  • Inactive lines fade based on distance from the current line
  • Click any line to instantly seek to that moment in the song
  • Falls back to plain text lyrics if sync data isn't available

  THEMES
  ──────
  8 built-in themes (Settings → Appearance):
    Green family:  GreenDark · GreenAmoled · GreenLight · GreenPurple
    Purple family: PurpleDark · PurpleAmoled · PurpleLight · PurplePurple

  RECENTLY PLAYED
  ───────────────
  • Persistent history saved between sessions
  • Remove individual entries with the ✕ button
  • Double-click any entry to replay it

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
  FILE LOCATIONS
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

  Settings & library data:   %AppData%\TakanaFy\
  yt-dlp binary:             %AppData%\TakanaFy\yt-dlp.exe
  Downloaded music:          %AppData%\TakanaFy\downloads\
  Stream cache (temp):       %TEMP%\TakanaFy_stream\

  To clear the stream cache manually:
    Settings → Playback & Cache → Clear Now

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
  TECH STACK
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

  Framework:    C# WPF on .NET 8 (net8.0-windows)
  Audio:        NAudio 2.2.1
  Tags:         TagLibSharp 2.3.0
  Discord RPC:  DiscordRichPresence 1.0.175
  JSON:         Newtonsoft.Json 13.0.3
  MVVM:         CommunityToolkit.Mvvm 8.2.2
  YouTube:      yt-dlp (auto-downloaded) + YouTube Data API v3
  Lyrics:       LRCLIB API (https://lrclib.net)
  Spotify:      Spotify Web API (HttpClient, no SDK)
  Last.fm:      Last.fm API (HttpClient)

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
  KNOWN LIMITATIONS
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

  • Spotify browsing only — playback requires Spotify Premium + SDK
    which is beyond the scope of this app. Use YouTube to play music.
  • Lyrics sync depends on LRCLIB's database. Not every song has
    timestamped lyrics — plain text is shown as a fallback.
  • YouTube streaming uses low-quality audio to minimize bandwidth.
    Use the Download button for best quality.
  • yt-dlp may occasionally fail on age-restricted or region-locked
    videos. This is a YouTube limitation, not a bug.

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
  Built with ♥ By Takana - tj3e : Discord / takanax69 : InstGram
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
