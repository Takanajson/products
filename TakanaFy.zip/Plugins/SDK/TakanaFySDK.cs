// ================================================================
//  TakanaFy Plugin SDK  —  paste this file into your plugin project
//  No reference to TakanaFy.exe needed.
//  Target framework must be: net8.0-windows
// ================================================================

using System;
using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;

namespace TakanaFy.Plugins
{
    // ── Required attribute ────────────────────────────────────────────
    [AttributeUsage(AttributeTargets.Class, Inherited = false)]
    public sealed class TakanaPluginAttribute : Attribute
    {
        public string Name        { get; }
        public string Version     { get; }
        public string Author      { get; }
        public string Description { get; }

        public TakanaPluginAttribute(string name, string version = "1.0.0",
            string author = "Unknown", string description = "")
        {
            Name = name; Version = version; Author = author; Description = description;
        }
    }

    // ── Base interface (all plugins must implement) ───────────────────
    public interface ITakanaPlugin : IDisposable
    {
        void Initialize(IPluginHost host);
        void Shutdown();
    }

    // ── Host API (what the app gives you) ─────────────────────────────
    public interface IPluginHost
    {
        // Events
        event EventHandler<SongInfo?>  SongChanged;
        event EventHandler<bool>       PlaybackStateChanged;
        event EventHandler<double>     PositionChanged;
        event EventHandler<double>     VolumeChanged;

        // Playback
        SongInfo? CurrentSong     { get; }
        bool      IsPlaying       { get; }
        double    PositionSeconds { get; set; }
        double    Volume          { get; set; }
        void      Play();
        void      Pause();
        void      Next();
        void      Previous();

        // Notifications & logging
        void ShowNotification(string message, NotificationKind kind = NotificationKind.Info);
        void Log(string message, LogLevel level = LogLevel.Info);
    }

    // ── Optional extension interfaces ─────────────────────────────────

    public interface IAudioPlugin : ITakanaPlugin
    {
        string ProcessorName { get; }
        int    Priority      { get; }
        bool   IsEnabled     { get; set; }
        void   ProcessAudio(float[] samples, int sampleRate, int channels);
    }

    public interface ILyricsPlugin : ITakanaPlugin
    {
        string ProviderName { get; }
        int    Priority     { get; }
        Task<LyricsData?> GetLyricsAsync(string title, string artist, CancellationToken ct = default);
    }

    public interface ISearchPlugin : ITakanaPlugin
    {
        string SourceName { get; }
        string SourceIcon { get; }
        Task<IReadOnlyList<SearchResult>> SearchAsync(string query, CancellationToken ct = default);
    }

    public interface IMetadataPlugin : ITakanaPlugin
    {
        string EnricherName { get; }
        Task EnrichAsync(SongInfo song, CancellationToken ct = default);
    }

    // ── Data classes ──────────────────────────────────────────────────

    public class SongInfo
    {
        public string   Id        { get; set; } = string.Empty;
        public string   Title     { get; set; } = string.Empty;
        public string   Artist    { get; set; } = string.Empty;
        public TimeSpan Duration  { get; set; }
        public string   FilePath  { get; set; } = string.Empty;
        public int      PlayCount { get; set; }
    }

    public class LyricsData
    {
        public string              PlainLyrics { get; set; } = string.Empty;
        public List<LyricLineData> SyncedLines { get; set; } = new();
        public bool                HasSync     => SyncedLines.Count > 0;
    }

    public class LyricLineData
    {
        public TimeSpan Time { get; set; }
        public string   Text { get; set; } = string.Empty;
    }

    public class SearchResult
    {
        public string   Id           { get; set; } = string.Empty;
        public string   Title        { get; set; } = string.Empty;
        public string   Author       { get; set; } = string.Empty;
        public TimeSpan Duration     { get; set; }
        public string   ThumbnailUrl { get; set; } = string.Empty;
        public string   Url          { get; set; } = string.Empty;
    }

    public enum NotificationKind { Info, Success, Warning, Error }
    public enum LogLevel         { Debug, Info, Warning, Error }
}
